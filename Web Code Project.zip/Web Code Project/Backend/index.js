import express from 'express';
import { initializeApp, cert } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import cors from 'cors';
import dotenv from 'dotenv';
import mysql from 'mysql2/promise';
import { readFileSync } from 'fs';

dotenv.config();
const app = express();

// Enhanced CORS configuration
app.use(cors({
  origin: ['http://localhost:5173', 'http://localhost:5000'],
  methods: ['GET', 'POST', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  credentials: true
}));

app.use(express.json());

// Firebase Admin Setup
const serviceAccount = JSON.parse(
  readFileSync('D:/Web Code Project/Backend/Secrets/service.json')
);
initializeApp({
  credential: cert(serviceAccount)
});

// Database Setup
const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: 'root123',
  database: 'temp1',
  port: 3306
});

// Token Verification Middleware
const verifyToken = async (req, res, next) => {
  const authHeader = req.headers.authorization;
  
  if (!authHeader?.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Unauthorized - No token provided' });
  }

  const token = authHeader.split(' ')[1];
  
  try {
    const decodedToken = await getAuth().verifyIdToken(token);
    req.user = {
      uid: decodedToken.uid,
      email: decodedToken.email
    };
    next();
  } catch (error) {
    console.error('Token verification failed:', error.message);
    return res.status(403).json({ error: 'Forbidden - Invalid token' });
  }
};

// Routes
app.post('/api/users', verifyToken, async (req, res) => {
    const { display_name, role } = req.body;
    
    try {
      // First check if user already exists
      const [existing] = await pool.execute(
        'SELECT user_id FROM users WHERE firebase_uid = ?',
        [req.user.uid]
      );
  
      if (existing.length > 0) {
        // User exists - update their record instead
        const [result] = await pool.execute(
          `UPDATE users 
           SET email = ?, display_name = ?, role = ?
           WHERE firebase_uid = ?`,
          [req.user.email, display_name, role || 'user', req.user.uid]
        );
        
        return res.json({
          message: 'User updated',
          user_id: existing[0].user_id
        });
      }
  
      // User doesn't exist - create new record
      const [result] = await pool.execute(
        `INSERT INTO users (firebase_uid, email, display_name, role) 
         VALUES (?, ?, ?, ?)`,
        [req.user.uid, req.user.email, display_name, role || 'user']
      );
      
      res.status(201).json({
        user_id: result.insertId,
        email: req.user.email,
        display_name,
        role: role || 'user'
      });
    } catch (err) {
      console.error('Database error:', err);
      res.status(500).json({ 
        error: 'Failed to create/update user record',
        details: err.message
      });
    }
  });
// Handle preflight requests
app.options('*', cors());

// Add
// 
//  these endpoints to your existing backend

// Add this to your backend routes
app.get('/api/user-subscription', verifyToken, async (req, res) => {
  try {
    const [subscription] = await pool.query(`
      SELECT 
        id,
        plan_id,
        status,
        start_date,
        end_date,
        price,
        features,
        created_at
      FROM subscriptions1
      WHERE user_id = ?
      ORDER BY created_at DESC
      LIMIT 1
    `, [req.user.uid]);

    if (!subscription.length) {
      return res.status(404).json({ error: 'No subscription found' });
    }

    res.json(subscription[0]);
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).json({ error: 'Failed to fetch subscription' });
  }
});

// Get user's subscription
app.get('/api/subscriptions', verifyToken, async (req, res) => {
    try {
      const [subscriptions] = await pool.execute(
        'SELECT * FROM subscriptions1 WHERE user_id = ?',
        [req.user.uid]
      );
      res.json(subscriptions);
    } catch (err) {
      console.error('Database error:', err);
      res.status(500).json({ error: 'Failed to fetch subscriptions' });
    }
  });
  
 // Create/update subscription
app.post('/api/subscriptions', verifyToken, async (req, res) => {
  try {
    const { plan_id, status, start_date, end_date, price, features } = req.body;
    
    // Validate required fields
    if (!plan_id || !price || !features) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    // Check for existing subscription
    const [existing] = await pool.execute(
      'SELECT id FROM subscriptions1 WHERE user_id = ?',
      [req.user.uid]
    );

    if (existing.length > 0) {
      // Update existing subscription
      await pool.execute(
        `UPDATE subscriptions1 SET
          plan_id = ?,
          status = ?,
          start_date = ?,
          end_date = ?,
          price = ?,
          features = ?
         WHERE user_id = ?`,
        [plan_id, status, start_date, end_date, price, features, req.user.uid]
      );
      return res.json({ 
        message: 'Subscription updated',
        plan_id,
        price,
        features: JSON.parse(features) // Parse back to object
      });
    }

    // Create new subscription
    const [result] = await pool.execute(
      `INSERT INTO subscriptions1 
        (user_id, plan_id, status, start_date, end_date, price, features)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [req.user.uid, plan_id, status, start_date, end_date, price, features]
    );
    
    res.status(201).json({
      subscription_id: result.insertId,
      plan_id,
      status,
      price,
      features: JSON.parse(features) // Parse back to object
    });
  } catch (err) {
    console.error('Database error:', err);
    res.status(500).json({ 
      error: 'Failed to create/update subscription',
      details: err.message 
    });
  }
});
  // GET /api/subscription-plans
//   app.get('/api/subscription-plans', async (req, res) => {
//     try {
//       const { rows } = await pool.query(`
//         SELECT plan_id, name, price, features, status 
//         FROM default_subscriptions
//         WHERE status = 'active'
//       `);
//       res.json(rows);
//     } catch (error) {
//       console.error('Error fetching plans:', error);
//       res.status(500).json({ error: 'Failed to fetch subscription plans' });
//     }
//   });
// // Middleware to authenticate user
// function authenticateUser(req, res, next) {
//   const authHeader = req.headers['authorization'];
//   const token = authHeader && authHeader.split(' ')[1];
  
//   if (!token) {
//     return res.status(401).json({ error: 'Unauthorized' });
//   }

//   // Verify the token (implementation depends on your auth system)
//   admin.auth().verifyIdToken(token)
//     .then(decodedToken => {
//       req.user = decodedToken;
//       next();
//     })
//     .catch(error => {
//       console.error('Token verification failed:', error);
//       res.status(401).json({ error: 'Unauthorized' });
//     });
// }

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});