// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import {getAuth,setPersistence, browserSessionPersistence} from "firebase/auth";
import { GoogleAuthProvider } from "firebase/auth";
import { getFirestore } from 'firebase/firestore';
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyC6CS3O0WCrB2LI98zaO_5jGQ5gPuDMsWU",
  authDomain: "web-code-project-592d4.firebaseapp.com",
  projectId: "web-code-project-592d4",
  storageBucket: "web-code-project-592d4.firebasestorage.app",
  messagingSenderId: "784778846907",
  appId: "1:784778846907:web:84b651456d01cc65493f9e",
  measurementId: "G-Y7SBXC0MWV"
};



// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

setPersistence(auth, browserSessionPersistence)
  .catch((error) => {
    console.error("Error setting auth persistence:", error);
  });


export {app,auth,db} 
 export const googleProvider = new GoogleAuthProvider();