import { auth, db } from "./firebase";
import { 
  createUserWithEmailAndPassword, 
  GoogleAuthProvider, 
  signInWithEmailAndPassword, 
  signInWithPopup,
  signOut,
  signInWithRedirect,
  updateProfile
} from "firebase/auth";
import { doc, setDoc, getDoc } from "firebase/firestore";

// Initialize Google provider
const googleProvider = new GoogleAuthProvider();

// Helper function to get user-friendly error messages
const getAuthErrorMessage = (errorCode) => {
  switch (errorCode) {
    case 'auth/email-already-in-use':
      return 'Email already in use. Please use another email.';
    case 'auth/invalid-email':
      return 'Invalid email address.';
    case 'auth/weak-password':
      return 'Password should be at least 6 characters.';
    case 'auth/user-not-found':
      return 'No user found with this email.';
    case 'auth/wrong-password':
      return 'Incorrect password.';
    case 'auth/popup-closed-by-user':
      return 'Sign in popup was closed before completing.';
    case 'auth/operation-not-allowed':
      return 'This operation is not allowed.';
    default:
      return 'An error occurred. Please try again.';
  }
};

// Helper function to create/update user document in Firestore
const handleUserDocument = async (user, additionalData = {}) => {
    if (!user) return;
    
    const userRef = doc(db, 'users', user.uid);
    try {
      await setDoc(userRef, {
        displayName: user.displayName,
        email: user.email,
        photoURL: user.photoURL || null,
        role: additionalData.role || 'user',
        createdAt: new Date(),
        ...additionalData
      }, { merge: true });
    } catch (error) {
      console.error("Error creating user document:", error);
      throw error;
    }
  };
  
  export const doCreateUserWithEmailAndPassword = async (email, password, displayName, role = 'user') => {
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      
      await updateProfile(userCredential.user, { displayName });
      
      // Explicitly pass the role
      await handleUserDocument(userCredential.user, { role });
      
      await userCredential.user.reload();
      return userCredential;
    } catch (error) {
      throw new Error(getAuthErrorMessage(error.code));
    }
  };

  export const doSignInWithEmailAndPassword = async (email, password) => {
    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      const userDoc = await getDoc(doc(db, 'users', userCredential.user.uid));
      
      if (!userDoc.exists()) {
        await signOut(auth);
        throw new Error('User not registered');
      }
      
      return {
        user: userCredential.user,
        role: userDoc.data().role || 'user'
      };
    } catch (error) {
      console.error("Sign in error:", error);
      throw error; // Throw the original error to preserve error.code
    }
  };
  
export const doSignInWithGoogle = async () => {
    try {
      const result = await signInWithPopup(auth, googleProvider);
      
      // First check if document exists to avoid permission errors
      const userDoc = await getDoc(doc(db, 'users', result.user.uid));
      
      if (!userDoc.exists()) {
        await handleUserDocument(result.user, { role: 'user' });
      }
      
      return result;
    } catch (error) {
      console.error("Google sign-in error:", error);
      throw new Error(getAuthErrorMessage(error.code));
    }
  };
  
export const doSignOut = async () => {
  try {
    await signOut(auth);
  } catch (error) {
    throw new Error(getAuthErrorMessage(error.code));
  }
};

// Role management functions
export const getUserRole = async (userId) => {
  try {
    const userDoc = await getDoc(doc(db, 'users', userId));
    return userDoc.exists() ? userDoc.data().role : null;
  } catch (error) {
    throw new Error('Failed to get user role');
  }
};

export const updateUserRole = async (userId, newRole) => {
  try {
    await setDoc(doc(db, 'users', userId), { role: newRole }, { merge: true });
  } catch (error) {
    throw new Error('Failed to update user role');
  }
};

export { googleProvider };