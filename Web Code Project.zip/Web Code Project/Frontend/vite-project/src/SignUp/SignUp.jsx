import { motion } from 'framer-motion';
import { Link, useNavigate } from 'react-router-dom';
import { FaGoogle, FaUser, FaEnvelope, FaLock, FaArrowRight, FaUserShield, FaUserTie, FaKey } from 'react-icons/fa';
import { useState } from 'react';
import { auth } from '../Firebase/firebase';
import { doCreateUserWithEmailAndPassword, doSignInWithGoogle } from '../Firebase/auth';
import { useAuth } from '../Context/authContext';
import './SignUp.css';

const SignUp = () => {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    displayName: '',
    role: 'user',
    adminCode: ''
  });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const { setUser } = useAuth();
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const createBackendUser = async (firebaseUser, role) => {
    try {
      const idToken = await firebaseUser.getIdToken();
      
      const response = await fetch(`http://localhost:5000/api/users`, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${idToken}`
        },
        body: JSON.stringify({
          display_name: formData.displayName,
          role: role
        })
      });
  
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to sync with backend');
      }
  
      const result = await response.json();
      
      // Handle both new user and updated user cases
      if (result.message === 'User updated') {
        console.log('Existing user record updated');
      } else {
        console.log('New user record created');
      }
      
      return result;
      
    } catch (error) {
      console.error('Backend user creation failed:', error);
      throw error;
    }
  };
  const handleSignUp = async (e) => {
    e.preventDefault();
    
    if (!formData.email || !formData.password || !formData.displayName) {
      setError('Please fill in all fields');
      return;
    }
    
    if (formData.role === 'admin' && formData.adminCode !== 'faisal123') {
      setError('Invalid admin access code');
      return;
    }

    try {
      setIsLoading(true);
      setError('');
      
      // 1. Firebase authentication
      const userCredential = await doCreateUserWithEmailAndPassword(
        formData.email,
        formData.password,
        formData.displayName,
        formData.role
      );
      
      // 2. Create backend record
      await createBackendUser(userCredential.user, formData.role);
      
      // 3. Set user context and redirect
      // setUser({
      //   ...userCredential.user,
      //   displayName: formData.displayName,
      //   role: formData.role
      // });
      
      navigate(formData.role === 'admin' ? '/Admin' : '/AfterSignUp');
      
    } catch (error) {
      console.error('Signup error:', error);
      setError(error.message);
      
      // Don't attempt to delete user - let them try again
    } finally {
      setIsLoading(false);
    }
  };
  const handleGoogleSignIn = async (e) => {
    e.preventDefault();
    
    if (formData.role === 'admin' && formData.adminCode !== 'faisal123') {
      setError('Invalid admin access code');
      return;
    }

    try {
      setIsLoading(true);
      setError('');
      
      const result = await doSignInWithGoogle();
      await createBackendUser(result.user, formData.role);
      // setUser(result.user);
      navigate(formData.role === 'admin' ? '/Admin' : '/AfterSignUp');
      
    } catch (error) {
      console.error('Google sign-in failed:', error);
      setError(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const handleRoleChange = (selectedRole) => {
    setFormData(prev => ({
      ...prev,
      role: selectedRole,
      adminCode: ''
    }));
  };

  return (
    <motion.div
      className="signup-container"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <div className="signup-card">
        <div className="decorative-circle circle-1"></div>
        <div className="decorative-circle circle-2"></div>

        {/* Role Selection */}
        <div className="role-toggle-container">
          <motion.div 
            className={`role-option ${formData.role === 'user' ? 'active' : ''}`}
            onClick={() => handleRoleChange('user')}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <FaUserTie className="role-icon" />
            <span>User</span>
          </motion.div>
          
          <motion.div 
            className={`role-option ${formData.role === 'admin' ? 'active' : ''}`}
            onClick={() => handleRoleChange('admin')}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <FaUserShield className="role-icon" />
            <span>Admin</span>
          </motion.div>
        </div>

        {/* Admin Code Input (Conditional) */}
        {formData.role === "admin" && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            transition={{ duration: 0.3 }}
            className="input-group admin-input"
          >
            <FaKey className="input-icon" />
            <input 
              type="password" 
              name="adminCode"
              placeholder="Admin Access Code" 
              value={formData.adminCode}
              onChange={handleChange}
              required
            />
            <div className="input-underline"></div>
          </motion.div>
        )}

        <motion.div
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="signup-header"
        >
          <h2>Create {formData.role === "admin" ? "Admin" : "User"} Account</h2>
          <p>Join our platform as a {formData.role}</p>
        </motion.div>

        <motion.form
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="signup-form"
          onSubmit={handleSignUp}
        >
          <div className="input-group">
            <FaUser className="input-icon" />
            <input 
              type="text" 
              name="displayName"
              placeholder="Full Name" 
              value={formData.displayName}
              onChange={handleChange}
              required
            />
            <div className="input-underline"></div>
          </div>

          <div className="input-group">
            <FaEnvelope className="input-icon" />
            <input 
              type="email" 
              name="email"
              placeholder="Email Address" 
              value={formData.email}
              onChange={handleChange}
              required
            />
            <div className="input-underline"></div>
          </div>

          <div className="input-group">
            <FaLock className="input-icon" />
            <input 
              type="password" 
              name="password"
              placeholder="Password (min 6 characters)" 
              value={formData.password}
              onChange={handleChange}
              minLength={6}
              required
            />
            <div className="input-underline"></div>
          </div>

          {error && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="error-message"
            >
              {error}
            </motion.div>
          )}

          <motion.button
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.98 }}
            className="signup-btn"
            type="submit"
            disabled={isLoading}
          >
            {isLoading ? (
              <span className="loading-spinner"></span>
            ) : (
              <>
                Register as {formData.role} <FaArrowRight />
              </>
            )}
          </motion.button>

          <div className="divider">OR</div>

          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={handleGoogleSignIn} 
            className="google-btn"
            disabled={isLoading}
            type="button"
          > 
            <FaGoogle /> Continue with Google
          </motion.button>
        </motion.form>

        <div className="signup-footer">
          <p>Already have an account? <Link to="/signin" className="login-link">Sign In</Link></p>
        </div>
      </div>
    </motion.div>
  );
};

export default SignUp;