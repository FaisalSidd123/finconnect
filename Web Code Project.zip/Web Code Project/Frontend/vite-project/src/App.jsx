import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './Context/authContext'; // Import AuthProvider
import SignUp from './SignUp/SignUp';
import AfterSignUp from './User/AfterSignUp';
import SignIn from './SignIn/SignIn';
import Admin from './Admin/Adminpanel';
import Payment from './Payment/Payment';
import { RoleProvider } from './Firebase/RoleContext'; // Import RoleProvider
import ProtectedRoute from './Firebase/ProtectedRoute'; // Import your ProtectedRoute component
import Unauthorized from './Unauthorized/Unauthorized';
import PrintView from './PrintView/PrintView'; 
 // Create this component for unauthorized access

function App() {
  return (
    <AuthProvider>
      <RoleProvider>
        <Router>
          <Routes>
            <Route path="/" element={<SignUp />} />
            <Route path="/signin" element={<SignIn />} />
            <Route path="/unauthorized" element={<Unauthorized />} />

            {/* Protected User Dashboard (accessible to all authenticated users) */}
            <Route element={<ProtectedRoute allowedRoles={['user', 'admin']} />}>
              <Route path="/AfterSignUp" element={<AfterSignUp />} />
            </Route>

            {/* Admin-only route */}
            <Route element={<ProtectedRoute allowedRoles={['admin']} />}>
              <Route path="/Admin" element={<Admin />} />
              </Route>
              <Route path="/payment" element={<Payment />} />
              <Route path="/printview" element={<PrintView />} />
              
              
              
            {/* </Route> */}
          </Routes>
        </Router>
      </RoleProvider>
    </AuthProvider>
  );
}

export default App;