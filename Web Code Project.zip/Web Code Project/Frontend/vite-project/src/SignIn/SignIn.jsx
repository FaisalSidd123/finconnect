import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../Context/authContext';
import { FaGoogle, FaEye, FaEyeSlash, FaUserShield, FaUserTie } from 'react-icons/fa';
import { motion } from "framer-motion";
import { doSignInWithEmailAndPassword, doSignInWithGoogle } from "../Firebase/auth";
import { doc, getDoc } from 'firebase/firestore';
import { db } from '../Firebase/firebase';
import './SignIn.css';
import '../SignUp/SignUp.css';

const SignIn = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [role, setRole] = useState("user");
  const [adminCode, setAdminCode] = useState("");
  
  const navigate = useNavigate();
  const { userLoggedIn } = useAuth();

  const onGoogleSignIn = async (e) => {
    e.preventDefault();
    
    // Admin verification for Google sign-in
    if (role === "admin" && adminCode !== "faisal123") {
        setError("Invalid admin access code");
        return;
      }
    
    try {
      setLoading(true);
      setError('');
      await doSignInWithGoogle(role);
      navigate(role === "admin" ? "/Admin" : "/AfterSignUp");
    } catch(error) {
      console.error("Google Sign in Failed", error);
      setError(mapAuthError(error.code));
    } finally {
      setLoading(false);
    }
  };

  const onEmailSignIn = async (e) => {
    e.preventDefault();
    
    if (!email || !password) {
      setError('Please fill in both email and password');
      return;
    }
  
    // Admin verification
    if (role === "admin" && adminCode !== "faisal123") {
      setError("Invalid admin access code");
      return;
    }
  
    try {
      setLoading(true);
      setError('');
      
      // Sign in and get user data with role
      const { user, role: userRole } = await doSignInWithEmailAndPassword(email, password);
      
      // Additional verification for admin
      if (role === "admin" && userRole !== "admin") {
        await signOut(auth);
        throw new Error('User does not have admin privileges');
      }
      
      // Redirect based on role
      navigate(userRole === "admin" ? "/Admin" : "/AfterSignUp");
      
    } catch(error) {
      console.error("Sign in failed:", error);
      setError(
        error.code ? getAuthErrorMessage(error.code) : 
        error.message || 'Sign in failed. Please try again.'
      );
    } finally {
      setLoading(false);
    }
  };

  const mapAuthError = (code) => {
    switch(code) {
      case 'auth/invalid-email': return 'Invalid email address';
      case 'auth/user-disabled': return 'This account has been disabled';
      case 'auth/user-not-found': return 'No account found with this email';
      case 'auth/wrong-password': return 'Incorrect password';
      case 'auth/too-many-requests': return 'Too many attempts. Try again later';
      case 'auth/popup-closed-by-user': return 'Google sign-in was canceled';
      case 'auth/network-request-failed': return 'Network error. Check your connection';
      default: return 'Login failed. Please try again';
    }
  };

  const handleRoleChange = (selectedRole) => {
    setRole(selectedRole);
    setAdminCode("");
  };

  return (
    <motion.div
      className="signin-container"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <div className="signin-card">
        {/* Role Selection */}
        <div className="role-toggle-container">
          <motion.div 
            className={`role-option ${role === 'user' ? 'active' : ''}`}
            onClick={() => handleRoleChange('user')}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <FaUserTie className="role-icon" />
            <span>User</span>
          </motion.div>
          
          <motion.div 
            className={`role-option ${role === 'admin' ? 'active' : ''}`}
            onClick={() => handleRoleChange('admin')}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <FaUserShield className="role-icon" />
            <span>Admin</span>
          </motion.div>
        </div>

        {/* Admin Code Input (Conditional) */}
        {role === "admin" && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            transition={{ duration: 0.3 }}
            className="form-group"
          >
            <div className="password-input">
              <input
                type={showPassword ? "text" : "password"}
                value={adminCode}
                onChange={(e) => setAdminCode(e.target.value)}
                placeholder="Enter admin code"
                required
              />
              <button 
                type="button" 
                className="toggle-password"
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? <FaEyeSlash /> : <FaEye />}
              </button>
            </div>
          </motion.div>
        )}

        <motion.h2
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.1 }}
        >
          {role === "admin" ? "Admin Sign In" : "User Sign In"}
        </motion.h2>
        
        {error && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="error-message"
          >
            {error}
          </motion.div>
        )}

        <motion.form
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          onSubmit={onEmailSignIn}
        >
          <div className="form-group">
            <label>Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="your@email.com"
              required
            />
          </div>

          <div className="form-group">
            <label>Password</label>
            <div className="password-input">
              <input
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                required
                minLength={6}
              />
              <button 
                type="button" 
                className="toggle-password"
                onClick={() => setShowPassword(!showPassword)}
                aria-label={showPassword ? "Hide password" : "Show password"}
              >
                {showPassword ? <FaEyeSlash /> : <FaEye />}
              </button>
            </div>
          </div>

          <motion.button
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.98 }}
            type="submit" 
            className="signin-button"
            disabled={loading}
          >
            {loading ? 'Signing In...' : 'Sign In'}
          </motion.button>
        </motion.form>

        <div className="divider">
          <span>OR</span>
        </div>

        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={onGoogleSignIn}
          className="google-button"
          disabled={loading}
          type="button"
        >
          <FaGoogle className="google-icon" />
          {loading ? 'Signing In...' : 'Continue with Google'}
        </motion.button>

        <div className="links-container">
          <Link to="/forgot-password" className="text-button">
            Forgot Password?
          </Link>
          <span>Don't have an account? <Link to="/">Sign Up</Link></span>
        </div>
      </div>
    </motion.div>
  );
};

export default SignIn;