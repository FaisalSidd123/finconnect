import { useState } from 'react';
import { FaCreditCard, FaLock, FaUser, FaCalendarAlt, FaCheck } from 'react-icons/fa';
import { motion } from 'framer-motion';
import './Payment.css';
import { useNavigate } from 'react-router-dom';
import PrintView from '../PrintView/PrintView';
const Payment = ({ plan, onPaymentSuccess, onBack }) => {
  const [cardDetails, setCardDetails] = useState({
    number: '',
    name: '',
    expiry: '',
    cvc: ''
  });
  const [errors, setErrors] = useState({});
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState(false);
  const navigate=useNavigate();
  const [isSubmitted,setSubmitted]=useState(false)
  const handleChange = (e) => {
    const { name, value } = e.target;
    setCardDetails(prev => ({ ...prev, [name]: value }));
  };

  const validateCard = () => {
    const newErrors = {};
    const cardRegex = /^[0-9]{16}$/;
    const expiryRegex = /^(0[1-9]|1[0-2])\/?([0-9]{2})$/;
    const cvcRegex = /^[0-9]{3,4}$/;

    if (!cardRegex.test(cardDetails.number.replace(/\s/g, ''))) {
      newErrors.number = 'Enter a valid 16-digit card number';
    }

    if (!cardDetails.name.trim()) {
      newErrors.name = 'Cardholder name is required';
    }

    if (!expiryRegex.test(cardDetails.expiry)) {
      newErrors.expiry = 'MM/YY format required';
    }

    if (!cvcRegex.test(cardDetails.cvc)) {
      newErrors.cvc = '3 or 4 digit CVC required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const formatCardNumber = (value) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    const matches = v.match(/\d{4,16}/g);
    const match = matches && matches[0] || '';
    const parts = [];
    
    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4));
    }
    
    return parts.length ? parts.join(' ') : value;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validateCard()) {
      setIsProcessing(true);
      // Simulate payment processing
      setTimeout(() => {
        setIsProcessing(false);
        setPaymentSuccess(true);
        setTimeout(() => onPaymentSuccess(), 2000);
      }, 3000);
      
    }
    
  };

  if (paymentSuccess) {
    return (
      <motion.div 
        className="payment-success"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
      >
        <div className="success-icon">
          <FaCheck />
        </div>
        <h2>Payment Successful!</h2>
        <p>You've successfully subscribed to  plan</p>
        <div className="success-details">
          <p>Amount charged: <span></span></p>
          <p>Card ending in: <span>{cardDetails.number.slice(-4)}</span></p>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div 
      className="payment-container"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
    >
      <div className="payment-header">
        <h2>Complete Your Payment</h2>
        <p>Enter your card details to subscribe to  plan</p>
        <div className="plan-price"><span>/month</span></div>
      </div>

      <form onSubmit={handleSubmit} className="payment-form">
        <div className={`input-group ${errors.number ? 'error' : ''}`}>
          <FaCreditCard className="input-icon" />
          <input
            type="text"
            name="number"
            placeholder="Card Number"
            value={formatCardNumber(cardDetails.number)}
            onChange={(e) => {
              e.target.value = formatCardNumber(e.target.value);
              handleChange(e);
            }}
            maxLength={19}
          />
          <div className="card-icons">
            <div className="card-icon visa"></div>
            <div className="card-icon mastercard"></div>
            <div className="card-icon amex"></div>
          </div>
          {errors.number && <span className="error-message">{errors.number}</span>}
        </div>

        <div className={`input-group ${errors.name ? 'error' : ''}`}>
          <FaUser className="input-icon" />
          <input
            type="text"
            name="name"
            placeholder="Cardholder Name"
            value={cardDetails.name}
            onChange={handleChange}
          />
          {errors.name && <span className="error-message">{errors.name}</span>}
        </div>

        <div className="row">
          <div className={`input-group ${errors.expiry ? 'error' : ''}`}>
            <FaCalendarAlt className="input-icon" />
            <input
              type="text"
              name="expiry"
              placeholder="MM/YY"
              value={cardDetails.expiry}
              onChange={(e) => {
                let value = e.target.value;
                if (value.length === 2 && !value.includes('/')) {
                  value = value + '/';
                }
                e.target.value = value;
                handleChange(e);
              }}
              maxLength={5}
            />
            {errors.expiry && <span className="error-message">{errors.expiry}</span>}
          </div>

          <div className={`input-group ${errors.cvc ? 'error' : ''}`}>
            <FaLock className="input-icon" />
            <input
              type="text"
              name="cvc"
              placeholder="CVC"
              value={cardDetails.cvc}
              onChange={handleChange}
              maxLength={4}
            />
            {errors.cvc && <span className="error-message">{errors.cvc}</span>}
          </div>
        </div>

        <div className="payment-actions">
          <button 
            type="button" 
            className="back-btn"
            onClick={onBack}
          >
            Back
          </button>
          <button 
            type="submit" 
            className="pay-btn"
            disabled={isProcessing}
          >
            {isProcessing ? (
              <>
                <div className="spinner"></div>
                Processing...
              </>
            ) : (
              ``
            )}
          </button>
        </div>

        <div className="security-info">
          <FaLock className="lock-icon" />
          <span>Your payment is secured with 256-bit encryption</span>
        </div>
      </form>
    </motion.div>
  );
};

export default Payment;