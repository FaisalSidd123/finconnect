import { useRef, useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { FaDownload, FaPrint, FaTimes, FaCheck } from 'react-icons/fa';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import './PrintView.css';
import { auth } from '../Firebase/firebase';

const PrintView = ({ 
  userData = {}, 
  planDetails = [], 
  onClose = () => {} 
}) => {
  const printRef = useRef();
  const [isGenerating, setIsGenerating] = useState(false);
  const [subscriptionData, setSubscriptionData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Fetch subscription data from backend
  useEffect(() => {
    const fetchSubscriptionData = async () => {
      try {
        const idToken = await auth.currentUser.getIdToken();
        const response = await fetch('http://localhost:5000/api/user-subscription', {
          headers: {
            'Authorization': `Bearer ${idToken}`
          }
        });

        if (!response.ok) {
          throw new Error('Failed to fetch subscription data');
        }

        const data = await response.json();
        setSubscriptionData(data);
      } catch (err) {
        console.error('Error fetching subscription:', err);
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchSubscriptionData();
  }, []);

  // Safely get plan details
  const currentPlan = planDetails.find(plan => plan?.id === subscriptionData?.plan_id) || { 
    name: subscriptionData?.plan_id || 'Unknown Plan',
    price: subscriptionData?.price || 0,
    features: []
  };

  // Format features for display
  const formatFeatures = (features) => {
    if (!features) return ['No features available'];
    if (Array.isArray(features)) return features;
    if (typeof features === 'string') {
      try {
        const parsed = JSON.parse(features);
        return Object.entries(parsed).map(([key, value]) => 
          `${key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}: ${value}`
        );
      } catch {
        return [features];
      }
    }
    return ['Features available'];
  };

  const handleDownloadPDF = async () => {
    setIsGenerating(true);
    try {
      const element = printRef.current;
      if (!element) return;

      const canvas = await html2canvas(element, {
        scale: 2,
        logging: false,
        useCORS: true,
        allowTaint: true,
        backgroundColor: '#ffffff'
      });

      const imgData = canvas.toDataURL('image/png', 1.0);
      const pdf = new jsPDF('p', 'mm', 'a4');
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = pdf.internal.pageSize.getHeight();
      
      pdf.setFillColor(245, 247, 250);
      pdf.rect(0, 0, pdfWidth, pdfHeight, 'F');
      
      const padding = 15;
      const contentWidth = pdfWidth - (padding * 2);
      const contentHeight = (canvas.height * contentWidth) / canvas.width;
      
      pdf.addImage(imgData, 'PNG', padding, padding, contentWidth, contentHeight);
      pdf.save(`${userData?.displayName || 'user'}_${currentPlan.name}_subscription.pdf`);
    } catch (error) {
      console.error('Error generating PDF:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    try {
      return new Date(dateString).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      });
    } catch {
      return 'Invalid date';
    }
  };

  if (loading) {
    return (
      <div className="print-view-container">
        <div className="loading-message">Loading subscription data...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="print-view-container">
        <div className="error-message">
          Error: {error}
          <button onClick={onClose} className="action-btn close-btn">
            <FaTimes /> Close
          </button>
        </div>
      </div>
    );
  }


  if (!subscriptionData) {
    return (
      <div className="print-view-container">
        <div className="no-subscription">
          No active subscription found
          <button onClick={onClose} className="action-btn close-btn">
            <FaTimes /> Close
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="print-view-container">
      <div className="print-actions">
        <button 
          onClick={handleDownloadPDF} 
          disabled={isGenerating}
          className="action-btn download-btn"
        >
          <FaDownload />
          {isGenerating ? 'Generating...' : 'Download PDF'}
        </button>
        <button onClick={handlePrint} className="action-btn print-btn">
          <FaPrint />
          Print
        </button>
        <button onClick={onClose} className="action-btn close-btn">
          <FaTimes />
          Close
        </button>
      </div>

      <div className="print-content" ref={printRef}>
        <div className="receipt-header">
          <div className="company-info">
            <div className="company-logo">PremiumHub</div>
            <p>123 Business Avenue, Tech City</p>
            <p>contact@premiumhub.com | (555) 123-4567</p>
          </div>
          <div className="receipt-title">
            <h2>Subscription Receipt</h2>
            <div className="receipt-meta">
              <p><strong>Receipt #:</strong> {subscriptionData.id || 'N/A'}</p>
              <p><strong>Date:</strong> {formatDate(subscriptionData.start_date)}</p>
            </div>
          </div>
        </div>

        <div className="divider"></div>

        <div className="user-info">
          <div>
            <h3>Billed To</h3>
            <p className="user-name">{userData?.displayName || 'Customer'}</p>
          </div>
          <div className="plan-highlight">
            <h3>Plan Information</h3>
            <div className="plan-badge">
              <span className="plan-id">ID: {subscriptionData.plan_id}</span>
              <span className="plan-name">{currentPlan.name}</span>
              <span className="plan-price">${subscriptionData.price || currentPlan.price}/month</span>
            </div>
          </div>
        </div>

        <div className="divider"></div>

        <div className="subscription-details">
          <div className="details-section">
            <h3>Subscription Details</h3>
            <div className="details-grid">
              <div className="detail-item">
                <span className="detail-label">Status:</span>
                <span className={`detail-value status-${subscriptionData.status?.toLowerCase()}`}>
                  {subscriptionData.status}
                </span>
              </div>
              <div className="detail-item">
                <span className="detail-label">Start Date:</span>
                <span className="detail-value">{formatDate(subscriptionData.start_date)}</span>
              </div>
              <div className="detail-item">
                <span className="detail-label">End Date:</span>
                <span className="detail-value">{formatDate(subscriptionData.end_date)}</span>
              </div>
              <div className="detail-item">
                <span className="detail-label">Billing Cycle:</span>
                <span className="detail-value">Monthly</span>
              </div>
            </div>
          </div>

          <div className="features-section">
            <h3>Plan Features</h3>
            <ul className="features-list">
              {formatFeatures(subscriptionData.features || currentPlan.features).map((feature, index) => (
                <li key={index}>
                  <FaCheck className="feature-icon" />
                  {feature}
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="divider"></div>

        <div className="payment-summary">
          <h3>Payment Summary</h3>
          <div className="summary-table">
            <div className="summary-row header">
              <span>Description</span>
              <span>Amount</span>
            </div>
            <div className="summary-row">
              <span>{currentPlan.name} Subscription</span>
              <span>${subscriptionData.price || currentPlan.price}</span>
            </div>
            <div className="summary-row total">
              <span>Total</span>
              <span>${subscriptionData.price || currentPlan.price}</span>
            </div>
          </div>
        </div>

        <div className="footer-note">
          <p>Thank you for your subscription! For any questions, please contact our support team.</p>
          <p className="small-text">This is an auto-generated receipt. No signature required.</p>
        </div>
      </div>
    </div>
  );
};

PrintView.propTypes = {
  userData: PropTypes.shape({
    uid: PropTypes.string,
    displayName: PropTypes.string,
    email: PropTypes.string
  }),
  planDetails: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
      name: PropTypes.string,
      price: PropTypes.number,
      features: PropTypes.oneOfType([
        PropTypes.array,
        PropTypes.string,
        PropTypes.object
      ])
    })
  ),
  onClose: PropTypes.func
};

export default PrintView;