import { useEffect, useState } from 'react';
import { useRole } from '../Firebase/RoleContext';
import { doSignOut} from '../Firebase/auth';
import { auth } from '../Firebase/firebase';
import { FaBell, FaSignOutAlt, FaCheck, FaCrown } from 'react-icons/fa';
import './AfterSignUp.css';
import { useNavigate } from 'react-router-dom';

const AfterSignUp = () => {
  const { currentUser, userRole } = useRole();
  const [activeTab, setActiveTab] = useState('dashboard');
  const [selectedPlan, setSelectedPlan] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showDropdown, setShowDropdown] = useState(false);
  const [subscriptionStatus, setSubscriptionStatus] = useState(null);
  const [isSubscribing, setIsSubscribing] = useState(false);
  const [subscriptionData, setSubscriptionData] = useState(null);
  const navigate=useNavigate()

  useEffect(() => {
    const timer = setTimeout(() => setIsLoading(false), 1500);
    fetchUserSubscription();
    return () => clearTimeout(timer);
  }, []);

  const subscriptionPlans = [
    {
      id: 'basic',
      name: 'Basic',
      price: 9.99,
      features: ['10 projects', '5GB storage', 'Basic support'],
      popular: false,
      icon: '📊'
    },
    {
      id: 'pro',
      name: 'Professional',
      price: 19.99,
      features: ['Unlimited projects', '50GB storage', 'Priority support', 'Advanced analytics'],
      popular: true,
      icon: '🚀'
    },
    {
      id: 'enterprise',
      name: 'Enterprise',
      price: 49.99,
      features: ['Unlimited projects', '1TB storage', '24/7 support', 'Dedicated account manager', 'API access'],
      popular: false,
      icon: '👑'
    },
    {
    id: 'ult',
    name: 'Ultimate',
    price: 49.99,
    features: ['Unlimited projects', '1TB storage', '24/7 support', 'Dedicated account manager', 'API access'],
    popular: false,
    icon: '👑',
    },

  ];

  const fetchUserSubscription = async () => {
    try {
      const idToken = await auth.currentUser.getIdToken();
      const response = await fetch('http://localhost:5000/api/subscriptions', {
        headers: {
          'Authorization': `Bearer ${idToken}`
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        if (data.length > 0) {
          setSelectedPlan(data[0].plan_id);
          setSubscriptionStatus(data[0].status);
          setSubscriptionData(data[0]);
        }
      }
    } catch (error) {
      console.error('Error fetching subscription:', error);
    }
  };

  const handleUpgrade = async (planId) => {
    if (isSubscribing || selectedPlan === planId) return;
    
    setIsSubscribing(true);
    try {
      const now = new Date();
      const endDate = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
      
      // Find the selected plan to get price and features
      const selectedPlanData = subscriptionPlans.find(plan => plan.id === planId);
      if (!selectedPlanData) throw new Error('Plan not found');
      
      const idToken = await auth.currentUser.getIdToken();
      const response = await fetch('http://localhost:5000/api/subscriptions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${idToken}`
        },
        body: JSON.stringify({
          plan_id: planId,
          status: 'active',
          start_date: now.toISOString().slice(0, 19).replace('T', ' '),
          end_date: endDate.toISOString().slice(0, 19).replace('T', ' '),
          price: selectedPlanData.price,
          features: JSON.stringify(selectedPlanData.features) // Convert features array to JSON string
        })
      });
  
      if (response.ok) {
        const result = await response.json();
        setSelectedPlan(planId);
        setSubscriptionStatus('active');
        setSubscriptionData({
          plan_id: planId,
          status: 'active',
          start_date: new Date().toISOString(),
          end_date: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
          price: selectedPlanData.price,
          features: selectedPlanData.features
        });
        navigate("/payment");
      } else {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Subscription failed');
      }
    } catch (error) {
      console.error('Subscription error:', error);
      alert(error.message);
    } finally {
      setIsSubscribing(false);
    }
  };
  const handleSignOut = async () => {
    try {
      await doSignOut();
    } catch (error) {
      console.error('Sign out error:', error);
    }
  };

  const formatDate = (dateString) => {
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  if (isLoading) {
    return (
      <div className="loading-screen">
        <div className="spinner"></div>
        <p>Loading your dashboard...</p>
      </div>
    );
  }

  return (
    <div className="dashboard-container">
      {/* Header Section */}
      <header className="dashboard-header">
        <div className="user-greeting">
          <h1>Welcome back, <span className="user-name">{currentUser?.displayName || 'User'}</span>!</h1>
          <p className="user-role">
            Account type: <span className={`role-${userRole}`}>{userRole}</span>
            {subscriptionData && (
              <>
                <span className="subscription-status">
                  | Subscription: <span className={`status-${subscriptionStatus}`}>
                    {subscriptionStatus} ({subscriptionData.plan_id})
                  </span>
                </span>
                {subscriptionStatus === 'active' && (
                  <span className="subscription-date">
                    | Renews on: {formatDate(subscriptionData.end_date)}
                  </span>
                )}
              </>
            )}
          </p>
        </div>
        <div className="header-actions">
          <button className="notification-btn">
            <FaBell />
            <span className="notification-badge">3</span>
          </button>
          <div className="user-avatar-container">
            <div 
              className="user-avatar"
              onClick={() => setShowDropdown(!showDropdown)}
            >
              {currentUser?.photoURL ? (
                <img src={currentUser.photoURL} alt="User avatar" />
              ) : (
                <span>{currentUser?.displayName?.charAt(0) || 'U'}</span>
              )}
            </div>
            {showDropdown && (
              <div className="user-dropdown">
                <div className="dropdown-header">
                  <p className="dropdown-name">{currentUser?.displayName}</p>
                  <p className="dropdown-email">{currentUser?.email}</p>
                </div>
                <div className="dropdown-item" onClick={handleSignOut}>
                  <FaSignOutAlt className="dropdown-icon" />
                  Sign Out
                </div>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Navigation Tabs */}
      <nav className="dashboard-tabs">
        <button 
          className={`tab-btn ${activeTab === 'dashboard' ? 'active' : ''}`}
          onClick={() => setActiveTab('dashboard')}
        >
          Dashboard
        </button>
        <button 
          className={`tab-btn ${activeTab === 'projects' ? 'active' : ''}`}
          onClick={() => setActiveTab('projects')}
        >
          My Projects
        </button>
        <button 
          className={`tab-btn ${activeTab === 'settings' ? 'active' : ''}`}
          onClick={() => setActiveTab('settings')}
        >
          Settings
        </button>
      </nav>

      {/* Main Content */}
      <main className="dashboard-content">
        {activeTab === 'dashboard' && (
          <>
            {/* Stats Cards */}
            <div className="stats-grid">
              <div className="stat-card">
                <h3>Projects</h3>
                <p className="stat-value">8</p>
                <p className="stat-change">+2 this week</p>
              </div>
              <div className="stat-card">
                <h3>Storage Used</h3>
                <p className="stat-value">
                  {subscriptionData?.plan_id === 'basic' ? '3.2' : 
                   subscriptionData?.plan_id === 'pro' ? '12.5' : '45.8'}GB
                </p>
                <p className="stat-change">
                  of {subscriptionData?.plan_id === 'basic' ? '5' : 
                      subscriptionData?.plan_id === 'pro' ? '50' : '1000'}GB
                </p>
              </div>
              <div className="stat-card">
                <h3>Productivity</h3>
                <p className="stat-value">87%</p>
                <div className="progress-bar">
                  <div className="progress-fill" style={{ width: '87%' }}></div>
                </div>
              </div>
            </div>

            {/* Subscription Plans */}
            <section className="subscription-section">
              <h2>Upgrade Your Plan</h2>
              <p className="section-description">Choose the plan that fits your needs</p>
              
              <div className="plans-grid">
                {subscriptionPlans.map(plan => (
                  <div 
                    key={plan.id} 
                    className={`plan-card ${plan.popular ? 'popular' : ''} ${selectedPlan === plan.id ? 'selected' : ''}`}
                  >
                    {plan.popular && <div className="popular-badge">Most Popular</div>}
                    <div className="plan-icon">{plan.icon}</div>
                    <h3>{plan.name}</h3>
                    <p className="plan-price">${plan.price}<span>/month</span></p>
                    <ul className="plan-features">
                      {plan.features.map((feature, index) => (
                        <li key={index}>
                          <FaCheck className="feature-check" /> {feature}
                        </li>
                      ))}
                    </ul>
                    <button 
                      className={`upgrade-btn ${selectedPlan === plan.id ? 'current' : ''}`}
                      onClick={() => handleUpgrade(plan.id)}
                      disabled={isSubscribing || selectedPlan === plan.id}
                    >
                      {selectedPlan === plan.id ? (
                        <>
                          <FaCheck /> Current Plan
                        </>
                      ) : (
                        isSubscribing ? 'Processing...' : 'Upgrade Now'
                      )}
                    </button>
                  </div>
                ))}
              </div>
            </section>
          </>
        )}

        {activeTab === 'projects' && (
          <div className="projects-container">
            <h2>My Projects</h2>
            <div className="projects-grid">
              {[1, 2, 3, 4, 5, 6].map(project => (
                <div key={project} className="project-card">
                  <h3>Project {project}</h3>
                  <p>Last updated: {new Date().toLocaleDateString()}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'settings' && (
          <div className="settings-container">
            <h2>Account Settings</h2>
            <div className="settings-card">
              <h3>Subscription Details</h3>
              {subscriptionData ? (
                <div className="subscription-details">
                  <p><strong>Plan:</strong> {subscriptionData.plan_id}</p>
                  <p><strong>Status:</strong> <span className={`status-${subscriptionData.status}`}>
                    {subscriptionData.status}
                  </span></p>
                  <p><strong>Start Date:</strong> {formatDate(subscriptionData.start_date)}</p>
                  <p><strong>End Date:</strong> {formatDate(subscriptionData.end_date)}</p>
                </div>
              ) : (
                <p>No active subscription</p>
              )}
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="dashboard-footer">
        <p>© {new Date().getFullYear()} Your Company Name. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default AfterSignUp;